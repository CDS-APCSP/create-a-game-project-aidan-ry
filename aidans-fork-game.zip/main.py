import os, time

health = 100
waffle = False
ReaperWaffles = False
TylerTheCreatorName = False

def startGame():
  os.system('clear') # clear the screen for the player
  print("Welcome to O block, you are playing as a chill dude named Tyler, attempting to get back to waffle land")
  print("you mission is to get enough waffles to trade in with a man called THE REAPER, you must collect 3 waffles by answering questions ")
  print()
  print()
  time.sleep(5)
  print("good luck on your journey!")
  time.sleep(2) # wait 3 seconds before moving on
  firstlight1() # runs to send the player to cave #1

def firstlight1():
  global waffle # use the waffle variable from the top
  os.system('clear')
  if waffle:
    print("there is nothing here for you yet, start over")
    #this is a Failsafe even though i dont need one
    waffle = False
    firstlight1()
  else:
    print("You are in the streets. There is a waffle on the ground, a cool shiney object to your left, and your best friend A$ap Rocky to your right. What would you like to do?")
  decision = input(">>").strip().lower()
  if decision.find("waffle") > -1:
    print("Hooray! We found our first waffle tyler great job! Lets take a little rest for the day and see what we can find tommorow.")
    waffle = True
    waffle = 1
    
    time.sleep(6)
    secondlight2()
  elif decision.find("left") > -1:
    print("Further investigation led to the discovery that turning left would lead you to the heart of O block, we do not want to go that way. Lets think again. ")
    time.sleep(7)
    firstlight1()
  elif decision.find("right") > -1:
    print("Proceeding right lets see what we find!.")
    time.sleep(4)
    print()
    print ("just kidding, you had the opportunity to get the waffle and you didnt get it, silly goose. Lets rethink that answer...")
    time.sleep(6)
    firstlight1()
  else:
    print("The directions were specific tyler, what you typed isn't a valid choice, try again")
    time.sleep(4)
    firstlight1()
  

def secondlight2():
  global explosives, health
  os.system('clear')
  print("Well, there is another light approaching, we have to keep our waffles or else we wont have enough waffles to give to the Reaper to get out of O block ")
  time.sleep(8)
  collectwaffledos()

def collectwaffledos():
  global waffle # use the waffle variable from the top
  os.system('clear')
  if waffle == 1:
    print("Hey tyler, you have arrived to another intersection, you are driving looking for some waffles. Would you like to take the turn to your left to see a picture of a t-rex or to your right and get a grammy award")
  else:
    print("How are you here without having enough waffles?")#if i did the program right, this text woud never have to be used i think
  decision = input(">>").strip().lower()
  
  if decision.find("left") > -1:
    print("turns out the t rex was real, you must start over")
    time.sleep(5)
    endGame()
  elif decision.find("right") > -1:
    print("Congradulations tyler, you have won your grammy award, and with that, came a waffle, good work today, we now have 2 waffles")

    waffle = 2
    time.sleep(5)
    GOTWAFFLETHREE()
  else:
    print("The directions were specific tyler, what you typed isn't a valid choice, try again")
    time.sleep(4)
    collectwaffledos()
  


def GOTWAFFLETHREE():
  global explosives, health
  os.system('clear')#come backkkckckckck
  print("we cannot lose our waffles, we have one more waffle to get before we can give them to the reaper")
  time.sleep(7)
  wafflehopefullytres()

def wafflehopefullytres():
  global waffle # use the waffle variable from the top
  os.system('clear')
  if waffle == 2:
    print("Now it is time to get personal, when is the next year that you will release music? 2023 r 2024")
  else:
    print("How did you get here without getting enough waffles?")
  decision = input(">>").strip().lower()

  if decision.find("2024") > -1:
    print("Incorrect, I cant believe you forgot when you were going to release music again, you must restart the agenda to get the correct amount of waffles, maybe then you will remember.")
    time.sleep(7)
    endGame()
  elif decision.find("2023") > -1:
    print("Correct! Since you have answered correctly, you get your final waffle.")
    waffle = 3
    print()
    print()
    time.sleep(3)
    print("lets go give these waffles to the reaper")
    time.sleep(6)
    ReaperGetsWaffles()
  else:
    print("Maybe you didnt read the question, try again...")
    time.sleep(4)
    wafflehopefullytres()
  

def endGame():
  os.system("clear")
  pass

def ReaperGetsWaffles():
  os.system("clear")
  if waffle == 3:
    print("The Reaper: Success! I have recieved these waffles and you have succesfully made it out of O block Tyler! Congradulations, I have a present for you")
    print()
    print()
    print("The Reaper: As I hold the name TheReaper, I have special powers. I have the power to give some of my musical power to an indivual. I have seen today that the individual is you. You are no long Tyler...")
    print()
    print()
    print("The Reaper: You are Tyler THE CREATOR, I have given you the ability to produce some of the most magical sounds the human ear has ever heard. You will bring joy to many, goodbye Tyler The Creator. ")
    TylerTheCreatorName = True

    print()
    print()
    print("the status of you being tyler the creator is.....")
    
    print(TylerTheCreatorName)
    time.sleep(15)
  os.system("clear")
  endGame()
  

startGame()

